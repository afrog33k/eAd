namespace eAd.Utilities
{
    public interface  IReporter
    {
        void Report(string message);
    }
}