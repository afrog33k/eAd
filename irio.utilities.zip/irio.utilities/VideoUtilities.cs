﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Security;
using System.Text;
using System.IO;
using System.Web;

namespace irio.utilities
{
public class VideoUtilities
{
    private static string FfmpegPath = "";

    private static bool FFmpegFound = false;
    private static string encodeArgs ="";

    static VideoUtilities()
    {
        if (HttpRuntime.AppDomainAppId != null)
        {
            //is web app
            FfmpegPath =
                HttpContext.Current.Request.MapPath(
                    HttpContext.Current.Request.ApplicationPath + "\\Tools\\FFmpeg\\ffmpeg.exe")
                ;
        }
        else
        {
            FfmpegPath = System.AppDomain.CurrentDomain.BaseDirectory + "Tools\\FFmpeg\\ffmpeg.exe";
        }




        if(!File.Exists(FfmpegPath))
        {
            Console.WriteLine("FFmpeg not found");
            FFmpegFound = false;
        }
        else
        {
            FFmpegFound = true;
        }
    }
    public static TimeSpan GetVideoDuration(string path)
    {
        if (FFmpegFound)
        {
            FileInfo Ffmpeg = new FileInfo(FfmpegPath);
            //FileInfo monitorFile =
            //    new FileInfo(Path.Combine(Ffmpeg.Directory.FullName,
            //                              "FFMpegMonitor_" + Guid.NewGuid().ToString() + ".txt"));

            //  string ffmpegpath = Environment.SystemDirectory + "\\cmd.exe";
            //   string ffmpegargs = "/C " + Ffmpeg.FullName + " " + encodeArgs;// + " 2>" + monitorFile.FullName;

            // string fullTestCmd = ffmpegpath + " " + ffmpegargs;
            encodeArgs = " -i " + path;

            Process ffmepg = new Process();
            ffmepg.StartInfo.FileName = FfmpegPath;
            ffmepg.StartInfo.UseShellExecute = false;
            ffmepg.StartInfo.RedirectStandardOutput = true;
            ffmepg.StartInfo.RedirectStandardError = true;
            ffmepg.StartInfo.CreateNoWindow = true;
            ffmepg.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
            ffmepg.StartInfo.Arguments = encodeArgs;
            ffmepg.EnableRaisingEvents = true;
            ffmepg.Start();
            string sDuration = ffmepg.StandardError.ReadToEnd().ToString();
            ffmepg.Close();
            ffmepg.Dispose();


            //if (!String.IsNullOrEmpty(proc.StandardError.ReadToEnd()))
            //{
            //    //Error occured
            //    return TimeSpan.Zero;
            //}




            string encodeLog = sDuration;
            var encodingLines = encodeLog.Split(System.Environment.NewLine[0]).Where(line => string.IsNullOrWhiteSpace(line) == false && string.IsNullOrEmpty(line.Trim()) == false).Select(s => s.Trim()).ToList();
            foreach (var line in encodingLines)
            {
                // Duration: 00:10:53.79, start: 0.000000, bitrate: 9963 kb/s
                if (line.StartsWith("Duration"))
                {
                    var duration = ParseDurationLine(line);
                    return duration;
                }
            }
        }
        else
        {
            return TimeSpan.Zero;
        }
        return  TimeSpan.Zero;
    }
    private static TimeSpan ParseDurationLine(string line)
    {
        var itemsOfData = line.Split(" "[0], "="[0]).Where(s => string.IsNullOrEmpty(s) == false).Select(s => s.Trim().Replace("=", string.Empty).Replace(",", string.Empty)).ToList();

        string duration = GetValueFromItemData(itemsOfData, "Duration:");

        return TimeSpan.Parse(duration);
    }

    private static string GetValueFromItemData(List<string> items, string targetKey)
    {
        var key = items.FirstOrDefault(i => i.ToUpper() == targetKey.ToUpper());

        if (key == null)
        {
            return null;
        }
        var idx = items.IndexOf(key);

        var valueIdx = idx + 1;

        if (valueIdx >= items.Count)
        {
            return null;
        }

        return items[valueIdx];
    }


    public unsafe static bool  GetVideoThumbnail(string path, string thumbname)
    {
        if (FFmpegFound)
        {
            FileInfo Ffmpeg = new FileInfo(FfmpegPath);
            //FileInfo monitorFile =
            //    new FileInfo(Path.Combine(Ffmpeg.Directory.FullName,
            //                              "FFMpegMonitor_" + Guid.NewGuid().ToString() + ".txt"));

            //  string ffmpegpath = Environment.SystemDirectory + "\\cmd.exe";
            //   string ffmpegargs = "/C " + Ffmpeg.FullName + " " + encodeArgs;// + " 2>" + monitorFile.FullName;
            encodeArgs = "-i " + path + " -vframes 1 -ss 00:00:07  -f mjpeg -s 320x240 -y " + thumbname;
            //if(!File.Exists(thumbname))
            //     File.Create(thumbname);
            // string fullTestCmd = ffmpegpath + " " + ffmpegargs;
            //  encodeArgs = " -itsoffset -4  -i " + path + " -vcodec mjpeg -vframes 1 -an -f rawvideo -s 320x240 " + thumbname;
            Process ffmepg = new Process();
            ffmepg.StartInfo.FileName = FfmpegPath;
            ffmepg.StartInfo.UseShellExecute = false;
            ffmepg.StartInfo.RedirectStandardOutput = true;
            ffmepg.StartInfo.RedirectStandardError = true;
            ffmepg.StartInfo.CreateNoWindow = true;
            ffmepg.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
            ffmepg.StartInfo.Arguments = encodeArgs;
            //ffmepg.StartInfo.UserName = "admin";
            //fixed (char *pass ="Green2o11" )
            //ffmepg.StartInfo.Password = new SecureString(pass,9);
            ffmepg.EnableRaisingEvents = true;
            ffmepg.Start();
            string sDuration = ffmepg.StandardError.ReadToEnd().ToString();
            ffmepg.Close();
            ffmepg.Dispose();

            string encodeLog = sDuration;
            var encodingLines = encodeLog.Split(Environment.NewLine[0]).Where(line => string.IsNullOrWhiteSpace(line) == false && string.IsNullOrEmpty(line.Trim()) == false).Select(s => s.Trim()).ToList();
            return true;
        }
        else
        {
            return false;
        }
        /*
                    return false;
        */
    }
}
}
