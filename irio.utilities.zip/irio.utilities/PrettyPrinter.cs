﻿using System;

namespace irio.utilities
{
public class PrettyPrinter
{
    private const int KB = 1024;
    private const int MB = KB * 1000;
    private const int GB = MB * 1000;


    /// <summary>
    ///
    /// </summary>
    /// <param name="bytes"></param>
    /// <returns></returns>

    public static string FormatByteCount(ulong bytes)
    {
        string format = null;

        if (bytes < KB)
        {
            format = String.Format("{0} Bytes", bytes);
        }
        else if (bytes < MB)
        {
            bytes = bytes / KB;
            format = String.Format("{0} kB", bytes.ToString("N"));
        }
        else if (bytes < GB)
        {
            double dree = bytes / MB;
            format = String.Format("{0} MB", dree.ToString("0.#"));
        }
        else
        {
            double gree = bytes / GB;
            format = String.Format( "{0} GB"
                                    , gree.ToString("0.#"));
        }

        return format;
    }
}
}