﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;

namespace irio.utilities
{ /// &lt;summary&gt;
    /// Image manipulation helper functionality.
    /// </summary>
public class ImageUtilities
{
   /// <summary>
        /// Re-sizes an image in size maintaing best possible quality.
        /// </summary>
        public static System.Drawing.Image HiqhQualityResize(System.Drawing.Image image, int width, int height)
        {
            System.Drawing.Image imgResized = new System.Drawing.Bitmap(width, height);
            System.Drawing.Graphics graphic = System.Drawing.Graphics.FromImage(imgResized);
            //Ensure high quality
            graphic.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
            graphic.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            graphic.PixelOffsetMode = System.Drawing.Drawing2D.PixelOffsetMode.HighQuality;
            graphic.CompositingQuality = System.Drawing.Drawing2D.CompositingQuality.HighQuality;
            //Resize
            graphic.DrawImage(image, 0, 0, width, height);
            return imgResized;
        }
        /// <summary>
        /// Crops an image.
        /// </summary>
        public static System.Drawing.Image Crop(System.Drawing.Image image, int cropWidth, int cropHeight, int startXPoint, int startYPoint)
        {
            System.Drawing.Image imgCropped = new System.Drawing.Bitmap(cropWidth, cropHeight);
            System.Drawing.Graphics graphic = System.Drawing.Graphics.FromImage(imgCropped);
            //Crop
            //graphic.DrawImage(image, startXPoint, startYPoint, cropWidth, cropHeight)
            graphic.DrawImage(image, new System.Drawing.Rectangle(0, 0, cropWidth, cropHeight), startXPoint, startYPoint, cropWidth, cropHeight, System.Drawing.GraphicsUnit.Pixel);
            return imgCropped;
        }
        /// <summary>
        /// Saves image as a high quality JPEG file.
        /// </summary>
        public static void SaveAsHighQualityJpegFile(ref System.Drawing.Image image, string filePath)
        {
            System.Drawing.Imaging.EncoderParameters encoderParameters = new System.Drawing.Imaging.EncoderParameters(1);
            encoderParameters.Param[0] = new System.Drawing.Imaging.EncoderParameter(System.Drawing.Imaging.Encoder.Quality, 100);
            System.Drawing.Imaging.ImageCodecInfo myImageCodecInfo = default(System.Drawing.Imaging.ImageCodecInfo);
            foreach (System.Drawing.Imaging.ImageCodecInfo codec in System.Drawing.Imaging.ImageCodecInfo.GetImageEncoders())
            {
                if (codec.MimeType == "image/jpeg")
                {
                    myImageCodecInfo = codec;
                    break; // TODO: might not be correct. Was : Exit For
                }
            }
            image.Save(filePath, myImageCodecInfo, encoderParameters);
        }
        /// <summary>
        /// Calculates the top left point (X, Y co-ordinates) where a crop must occur to provide as much of the central image as possible.
        /// </summary>
        /// <param name="sourceWidth">Width to be cropped from.</param>
        /// <param name="sourceHeight">Height to be cropped from.</param>
        /// <param name="cropWidth">Crop width.</param>
        /// <param name="cropHeight">Crop height.</param>
        /// <returns>Point with X, Y co-ordinates.</returns>
        public static System.Drawing.Point GetTopLeftStartCropPointForKeepCenter(int sourceWidth, int sourceHeight, int cropWidth, int cropHeight)
        {
            System.Drawing.Point pointStart = new System.Drawing.Point();
            //X
            pointStart.X = (int)(sourceWidth - cropWidth) / 2;
            if (cropWidth + (pointStart.X * 2) < sourceWidth) pointStart.X -= 1;
            //Y
            pointStart.Y = (int)(sourceHeight - cropHeight) / 2;
            if (cropHeight + (pointStart.Y * 2) < sourceHeight) pointStart.Y -= 1;
            return pointStart;
        }
    


    public  static  void SaveImage(Bitmap Image, string path, System.Drawing.Imaging.ImageFormat format, bool Dispose)
    {

        FileUtilities.FolderCreate(Path.GetDirectoryName(path));
        System.IO.FileStream memoryStream = new FileStream(path,FileMode.Create);

        Image.Save(memoryStream, format);
        if(Dispose)
            Image.Dispose();
        memoryStream.Dispose();


    }
    /// <summary>
    /// Resizes and rotates an image, keeping the original aspect ratio. Does not dispose the original
    /// Image instance.
    /// </summary>
    /// <param name="image">Image instance</param>
    /// <param name="width">desired width</param>
    /// <param name="height">desired height</param>
    /// <param name="rotateFlipType">desired RotateFlipType</param>
    /// <returns>new resized/rotated Image instance</returns>
    public static Image Resize(Image image, int width, int height, RotateFlipType rotateFlipType)
    {
        // clone the Image instance, since we don't want to resize the original Image instance
        var rotatedImage = image.Clone() as Image;
        rotatedImage.RotateFlip(rotateFlipType);
        var newSize = CalculateResizedDimensions(rotatedImage, width, height);

        var resizedImage = new Bitmap(newSize.Width, newSize.Height, PixelFormat.Format24bppRgb);
        resizedImage.SetResolution(72, 72);

        using (var graphics = Graphics.FromImage(resizedImage))
        {
            // set parameters to create a high-quality thumbnail
            graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
            graphics.SmoothingMode = SmoothingMode.AntiAlias;
            graphics.CompositingQuality = CompositingQuality.HighQuality;
            graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;

            // use an image attribute in order to remove the black/gray border around image after resize
            // (most obvious on white images), see this post for more information:
            // http://www.codeproject.com/KB/GDI-plus/imgresizoutperfgdiplus.aspx
            using (var attribute = new ImageAttributes())
            {
                attribute.SetWrapMode(WrapMode.TileFlipXY);

                // draws the resized image to the bitmap
                graphics.DrawImage(rotatedImage, new Rectangle(new Point(0, 0), newSize), 0, 0, rotatedImage.Width, rotatedImage.Height, GraphicsUnit.Pixel, attribute);
            }
        }

        return resizedImage;
    }

    /// <summary>
    /// Calculates resized dimensions for an image, preserving the aspect ratio.
    /// </summary>
    /// <param name="image">Image instance</param>
    /// <param name="desiredWidth">desired width</param>
    /// <param name="desiredHeight">desired height</param>
    /// <returns>Size instance with the resized dimensions</returns>
    private static Size CalculateResizedDimensions(Image image, int desiredWidth, int desiredHeight)
    {
        var widthScale = (double)desiredWidth / image.Width;
        var heightScale = (double)desiredHeight / image.Height;

        // scale to whichever ratio is smaller, this works for both scaling up and scaling down
        var scale = widthScale < heightScale ? widthScale : heightScale;

        return new Size
        {
            Width = (int)(scale * image.Width),
            Height = (int)(scale * image.Height)
        };
    }


    //public static string ResizePicture(File file,string filePath, int bmpW, int bmpH)
    // {





    //     if (!string.IsNullOrEmpty(file.FileName))
    //     {


    //         //Check to make sure the file to upload has a picture file format extention


    //         if ((CheckFileType(file.FileName)))
    //         {
    //             int newWidth = bmpW;

    //             int newHeight = bmpH;

    //             //Use the uploaded filename without the '.' extension

    //             //	string upName = String.Mid(FileName, 1, (Strings.InStr(FileName, ".") - 1));



    //             //Create a new Bitmap using the uploaded picture as a Stream

    //             //Set the new bitmap resolution to 72 pixels per inch

    //             Bitmap upBmp = (Bitmap)Bitmap.FromStream(file.InputStream);

    //             Bitmap newBmp = new Bitmap(newWidth, newHeight, PixelFormat.Format24bppRgb);

    //             newBmp.SetResolution(72, 72);

    //             //Get the uploaded image width and height

    //             int upWidth = upBmp.Width;

    //             int upHeight = upBmp.Height;

    //             int newX = 0;

    //             int newY = 0;

    //             float reDuce = 0.0f;

    //             //Keep the aspect ratio of image the same if not 4:3 and work out the newX and newY positions

    //             //to ensure the image is always in the centre of the canvas vertically and horizontally

    //             //Landscape picture
    //             if (upWidth > upHeight)
    //             {

    //                 reDuce = (float)newWidth / upWidth;
    //                 //calculate the width percentage reduction as decimal

    //                 newHeight = (int)(upHeight * reDuce);
    //                 //reduce the uploaded image height by the reduce amount

    //                 newY = ((bmpH - newHeight) / 2);
    //                 //Position the image centrally down the canvas

    //                 newX = 0;
    //                 //Picture will be full width

    //                 //Portrait picture
    //             }
    //             else if (upWidth < upHeight)
    //             {

    //                 reDuce = (float)newHeight / upHeight;
    //                 //calculate the height percentage reduction as decimal

    //                 newWidth = (int)(upWidth * reDuce);
    //                 //reduce the uploaded image height by the reduce amount

    //                 newX = (int)((bmpW - newWidth) / 2);
    //                 //Position the image centrally across the canvas

    //                 newY = 0;
    //                 //Picture will be full hieght

    //                 //square picture
    //             }
    //             else if (upWidth == upHeight)
    //             {

    //                 reDuce = (float)newHeight / upHeight;
    //                 //calculate the height percentage reduction as decimal

    //                 newWidth = (int)(upWidth * reDuce);
    //                 //reduce the uploaded image height by the reduce amount

    //                 newX = ((bmpW - newWidth) / 2);
    //                 //Position the image centrally across the canvas

    //                 newY = ((bmpH - newHeight) / 2);
    //                 //Position the image centrally down the canvas

    //             }

    //             //Create a new image from the uploaded picture using the Graphics class

    //             //Clear the graphic and set the background colour to white

    //             //Use Antialias and High Quality Bicubic to maintain a good quality picture

    //             //Save the new bitmap image using 'Png' picture format and the calculated canvas positioning

    //             Graphics newGraphic = Graphics.FromImage(newBmp);


    //             try
    //             {
    //                 newGraphic.Clear(Color.White);

    //                 newGraphic.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

    //                 newGraphic.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;

    //                 newGraphic.DrawImage(upBmp, newX, newY, newWidth, newHeight);

    //                 if (!FileUtils.FolderExists(Path.GetDirectoryName(filePath)))
    //                 {
    //                     FileUtils.FolderCreate(Path.GetDirectoryName(filePath));
    //                 }

    //                 newBmp.Save(filePath, System.Drawing.Imaging.ImageFormat.Png);

    //                 //Show the uploaded resized picture in the image control

    //                 //Image1.ImageUrl = filePath;

    //                 //Image1.Visible = true;
    //                 return filePath;

    //             }
    //             catch (Exception ex)
    //             {
    //                 //lblError.Text = ex.ToString();


    //             }
    //             finally
    //             {
    //                 upBmp.Dispose();

    //                 newBmp.Dispose();

    //                 newGraphic.Dispose();

    //             }


    //         }
    //         else
    //         {
    //             //lblError.Text = "Please select a picture with a file format extension of either Bmp, Jpg, Jpeg, Gif or Png.";
    //             return null;

    //         }

    //     }
    //     return null;

    // }

    // public static string ResizePictureThumb(HttpPostedFileBase file, string filePath)
    // {

    //     dynamic bmpW = 216;
    //     //New image canvas width

    //     dynamic bmpH = 132;
    //     //New Image canvas height


    //     if (!string.IsNullOrEmpty(file.FileName))
    //     {


    //         //Check to make sure the file to upload has a picture file format extention


    //         if ((CheckFileType(file.FileName)))
    //         {
    //             int newWidth = bmpW;

    //             int newHeight = bmpH;

    //             //Use the uploaded filename without the '.' extension

    //             //	string upName = String.Mid(FileName, 1, (Strings.InStr(FileName, ".") - 1));



    //             //Create a new Bitmap using the uploaded picture as a Stream

    //             //Set the new bitmap resolution to 72 pixels per inch

    //             Bitmap upBmp = (Bitmap)Bitmap.FromStream(file.InputStream);

    //             Bitmap newBmp = new Bitmap(newWidth, newHeight, System.Drawing.Imaging.PixelFormat.Format24bppRgb);

    //             newBmp.SetResolution(72, 72);

    //             //Get the uploaded image width and height

    //             int upWidth = upBmp.Width;

    //             int upHeight = upBmp.Height;

    //             int newX = 0;

    //             int newY = 0;

    //             float reDuce = 0.0f;

    //             //Keep the aspect ratio of image the same if not 4:3 and work out the newX and newY positions

    //             //to ensure the image is always in the centre of the canvas vertically and horizontally

    //             //Landscape picture
    //             if (upWidth > upHeight)
    //             {

    //                 reDuce = (float)newWidth / upWidth;
    //                 //calculate the width percentage reduction as decimal

    //                 newHeight = (int)(upHeight * reDuce);
    //                 //reduce the uploaded image height by the reduce amount

    //                 newY = ((bmpH - newHeight) / 2);
    //                 //Position the image centrally down the canvas

    //                 newX = 0;
    //                 //Picture will be full width

    //                 //Portrait picture
    //             }
    //             else if (upWidth < upHeight)
    //             {

    //                 reDuce = (float)newHeight / upHeight;
    //                 //calculate the height percentage reduction as decimal

    //                 newWidth = (int)(upWidth * reDuce);
    //                 //reduce the uploaded image height by the reduce amount

    //                 newX = (int)((bmpW - newWidth) / 2);
    //                 //Position the image centrally across the canvas

    //                 newY = 0;
    //                 //Picture will be full hieght

    //                 //square picture
    //             }
    //             else if (upWidth == upHeight)
    //             {

    //                 reDuce = (float)newHeight / upHeight;
    //                 //calculate the height percentage reduction as decimal

    //                 newWidth = (int)(upWidth * reDuce);
    //                 //reduce the uploaded image height by the reduce amount

    //                 newX = ((bmpW - newWidth) / 2);
    //                 //Position the image centrally across the canvas

    //                 newY = ((bmpH - newHeight) / 2);
    //                 //Position the image centrally down the canvas

    //             }

    //             //Create a new image from the uploaded picture using the Graphics class

    //             //Clear the graphic and set the background colour to white

    //             //Use Antialias and High Quality Bicubic to maintain a good quality picture

    //             //Save the new bitmap image using 'Png' picture format and the calculated canvas positioning

    //             Graphics newGraphic = Graphics.FromImage(newBmp);


    //             try
    //             {
    //                 newGraphic.Clear(Color.White);

    //                 newGraphic.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

    //                 newGraphic.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;

    //                 newGraphic.DrawImage(upBmp, newX, newY, newWidth, newHeight);

    //                 if (!FileUtils.FolderExists(Path.GetDirectoryName(filePath)))
    //                 {
    //                     FileUtils.FolderCreate(Path.GetDirectoryName(filePath));
    //                 }

    //                 newBmp.Save(filePath, System.Drawing.Imaging.ImageFormat.Jpeg);

    //                 //Show the uploaded resized picture in the image control

    //                 //Image1.ImageUrl = filePath;

    //                 //Image1.Visible = true;
    //                 return filePath;

    //             }
    //             catch (Exception ex)
    //             {
    //                 //lblError.Text = ex.ToString();


    //             }
    //             finally
    //             {
    //                 upBmp.Dispose();

    //                 newBmp.Dispose();

    //                 newGraphic.Dispose();

    //             }


    //         }
    //         else
    //         {
    //             //lblError.Text = "Please select a picture with a file format extension of either Bmp, Jpg, Jpeg, Gif or Png.";
    //             return null;

    //         }

    //     }
    //     return null;

    // }
}
}
