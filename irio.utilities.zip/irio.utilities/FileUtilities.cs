﻿using System.Drawing;
using System.IO;

namespace irio.utilities
{
public static class FileUtilities
{

    //public  static void FolderCreate(string FolderName)
    //{
    //    DirectoryInfo directoryInfo = new DirectoryInfo(FolderName);
    //    if(directoryInfo.Parent !=null)
    //        FolderCreate(directoryInfo.Parent.FullName);
    //    if(!directoryInfo.Exists)
    //        directoryInfo.Create();
    //}

    public static void SaveStream(Stream input , string path, bool Dispose)
    {

        FolderCreate(Path.GetDirectoryName(path));

        using (var fileStream = new FileStream(path, FileMode.Create))
        {
            input.CopyTo(fileStream);
        }
    }

    public static bool FileExists(string FileFullPath)
    {
        FileInfo f = new FileInfo(FileFullPath);
        return f.Exists;
    }


    public static bool FolderExists(string FolderPath)
    {
        DirectoryInfo f = new DirectoryInfo(FolderPath);
        return f.Exists;
    }


    public static void FolderDelete(string FolderPath)
    {
        DirectoryInfo f = new DirectoryInfo(FolderPath);

        if (f.Exists)
            f.Delete(true);
    }


    /// <summary>
    /// Recursively create directory
    /// </summary>
    /// <param name="folderName">Folder path to create.</param>
    public static void FolderCreate(string folderName)
    {
        DirectoryInfo directoryInfo = new DirectoryInfo(folderName);
        if (directoryInfo.Parent != null)
            FolderCreate(directoryInfo.Parent.FullName);
        if (!directoryInfo.Exists)
            directoryInfo.Create();
    }
}
}